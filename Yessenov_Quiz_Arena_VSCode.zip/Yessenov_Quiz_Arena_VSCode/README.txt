YESSENOV QUIZ ARENA — VS CODE

1) Осы папкадағы барлық файлды бірге сақтаңыз.
2) VS Code-та осы папканы ашыңыз.
3) Terminal > New Terminal ашыңыз.
4) npm install орындаңыз.
5) npm start орындаңыз.
6) Компьютерде http://localhost:3000/host ашыңыз.
7) Телефондардан сол Wi-Fi желісінде http://КОМПЬЮТЕР_IP:3000/ ашылады.

Render арқылы интернетке шығару:
- GitHub репозиторийінің ТҮБІНЕ осы 7 файлды жүктеңіз.
- Build Command: npm install
- Start Command: npm start
- Root Directory бос қалсын.
- Render сервисінің адресі/host беті: https://СІЗДІҢ-АДРЕСІҢІЗ.onrender.com/host
- Қатысушыларға негізгі сілтеме/QR: https://СІЗДІҢ-АДРЕСІҢІЗ.onrender.com/

ЕСКЕРТУ: Бұл бастапқы нұсқа. Render тегін сервисі ұйқы режиміне өтуі мүмкін; сервер қайта іске қосылса, ағымдағы ойын қатысушылары мен ұпайлары жадыдан өшеді.
