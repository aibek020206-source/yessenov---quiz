const express=require('express');
const http=require('http');
const {Server}=require('socket.io');
const QRCode=require('qrcode');
const path=require('path');
const app=express(), server=http.createServer(app), io=new Server(server);
const PORT=process.env.PORT||3000;
// Барлық HTML/CSS/JS файлдары server.js-пен бір папкада орналасады.
app.use(express.static(__dirname));
app.get('/',(req,res)=>res.sendFile(path.join(__dirname,'player.html')));
app.get('/host',(req,res)=>res.sendFile(path.join(__dirname,'host.html')));
app.get('/health',(req,res)=>res.send('OK'));
const questions=[
['Қазақстан тәуелсіздігін қай жылы жариялады?',['1990','1991','1992','1993'],1],
['Қазақстанның ұлттық валютасы?',['Рубль','Сом','Теңге','Манат'],2],
['ҚР мемлекеттік туының авторы кім?',['Шәкен Ниязбеков','Әбілхан Қастеев','Шота Уәлиханов','Нұрғиса Тілендиев'],0],
['Қазақстанның астанасы?',['Алматы','Астана','Ақтау','Шымкент'],1],
['Қазақстанда неше облыс бар?',['17','14','20','21'],0],
['Компьютердің негізгі есептеу құрылғысы?',['Жедел жад','Процессор','Монитор','Пернетақта'],1],
['1 байтта неше бит бар?',['4','8','16','32'],1],
['HTML не үшін қолданылады?',['Веб-бет құрылымы','Дерекқор','Видео өңдеу','Операциялық жүйе'],0],
['Интернет беттерін ашатын бағдарлама?',['Браузер','Архиватор','Компилятор','Драйвер'],0],
['Wi-Fi нені қамтамасыз етеді?',['Сымсыз байланыс','Қағаз басу','Дыбыс жазу','Файл сығу'],0],
['BIM қысқартуы нені білдіреді?',['Building Information Modeling','Basic Internet Map','Building Internal Material','Binary Information Mode'],0],
['Revit қай салада қолданылады?',['Музыка','BIM және жобалау','Видео монтаж','Медицина'],1],
['Геодезия нені зерттейді?',['Жер өлшеу','Ауа райы','Өсімдіктер','Ғарыш кемелері'],0],
['3D модель не үшін қажет?',['Тек әдемілік','Нысанды кеңістікте көрсету','Интернет жылдамдату','Мәтін теру'],1],
['Коллизия дегеніміз не?',['Элементтердің қақтығысуы','Түстің өзгеруі','Файл сақтау','Модель атауы'],0],
['Электр тогының өлшем бірлігі?',['Вольт','Ампер','Ом','Ватт'],1],
['Кернеудің өлшем бірлігі?',['Ампер','Ом','Вольт','Герц'],2],
['Кедергінің өлшем бірлігі?',['Ом','Ватт','Вольт','Ампер'],0],
['Электр қуатының өлшем бірлігі?',['Джоуль','Ватт','Ом','Кулон'],1],
['Энергияны үнемдеу жолы?',['Жарықты жағу','Үнемді шам қолдану','Құрылғыны қоса қалдыру','Терезені ашу'],1],
['Қазақстанның ең үлкен теңізі?',['Арал','Каспий','Балқаш','Зайсан'],1],
['Ақтау қай облыстың орталығы?',['Атырау','Маңғыстау','Ақтөбе','Қызылорда'],1],
['Жердің табиғи серігі?',['Марс','Күн','Ай','Шолпан'],2],
['Судың химиялық формуласы?',['CO2','H2O','O2','NaCl'],1],
['Күн жүйесіндегі ең үлкен ғаламшар?',['Жер','Сатурн','Юпитер','Марс'],2]
].map((q,i)=>({id:i,text:q[0],options:q[1],correct:q[2]}));
let players=[],teams=[],phase='lobby',round=0,index=0,endsAt=null,timer=null,hostId=null;
const state=()=>({players:players.map(({id,name,team,leader})=>({id,name,team,leader})),teams:teams.map(t=>({...t})),phase,round,index,endsAt,question:['question','reveal'].includes(phase)?{text:questions[round*5+index]?.text,options:questions[round*5+index]?.options}:null});
const send=()=>io.emit('state',state());
function stop(){if(timer)clearInterval(timer);timer=null;}
function startQuestion(){stop();if(round>=5){phase='finished';endsAt=null;send();return;}phase='question';teams.forEach(t=>{t.answered=false;t.correct=null;});endsAt=Date.now()+30000;timer=setInterval(()=>{const left=Math.max(0,Math.ceil((endsAt-Date.now())/1000));io.emit('tick',left);if(left===0){stop();phase='reveal';endsAt=null;send();}},250);send();}
io.on('connection',s=>{s.emit('state',state());s.on('hostRegister',()=>{hostId=s.id;s.emit('hostReady');send();});s.on('join',raw=>{const name=String(raw||'').trim().slice(0,30);if(!name)return s.emit('joinError','Атыңды енгіз.');if(phase!=='lobby')return s.emit('joinError','Ойын басталып кетті.');if(players.length>=20)return s.emit('joinError','20 қатысушы толды.');if(players.some(p=>p.name.toLowerCase()===name.toLowerCase()))return s.emit('joinError','Бұл есім тіркелген.');players.push({id:s.id,name,team:null,leader:false});s.emit('joined',{id:s.id});send();});s.on('makeTeams',()=>{if(s.id!==hostId)return;if(players.length!==20)return s.emit('hostMessage','20 қатысушы толық жиналсын.');const a=[...players].sort(()=>Math.random()-.5);teams=Array.from({length:5},(_,i)=>({id:i+1,name:`${i+1}-топ`,members:a.slice(i*4,i*4+4).map(p=>p.id),leaderId:null,score:0,answered:false,correct:null}));teams.forEach(t=>{t.leaderId=t.members[Math.floor(Math.random()*4)];t.members.forEach(id=>{const p=players.find(x=>x.id===id);p.team=t.name;p.leader=id===t.leaderId;});});send();s.emit('hostMessage','Топтар мен көшбасшылар таңдалды!');});s.on('startGame',()=>{if(s.id!==hostId||teams.length!==5||phase!=='lobby')return;round=0;index=0;startQuestion();});s.on('answer',n=>{if(phase!=='question')return;const p=players.find(x=>x.id===s.id);if(!p||!p.leader)return;const t=teams.find(x=>x.name===p.team);if(!t||t.answered)return;const ok=Number(n)===questions[round*5+index].correct;t.answered=true;t.correct=ok;if(ok)t.score+=10;s.emit('answerResult',{correct:ok});send();if(teams.every(x=>x.answered)){stop();phase='reveal';endsAt=null;send();}});s.on('nextQuestion',()=>{if(s.id!==hostId||phase!=='reveal')return;index++;if(index===5){index=0;round++;}startQuestion();});s.on('disconnect',()=>{if(s.id===hostId)hostId=null;});});
app.get('/qr',async(req,res)=>{const proto=req.headers['x-forwarded-proto']||req.protocol;const url=`${proto}://${req.get('host')}/`;try{res.json({url,data:await QRCode.toDataURL(url,{width:260})});}catch(e){res.status(500).json({error:'QR error'});}});
server.listen(PORT,'0.0.0.0',()=>console.log('Quiz server running on '+PORT));
